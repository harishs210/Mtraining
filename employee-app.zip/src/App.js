import logo from './logo.svg';
import './App.css';
import Employee from './Components/Employee';
import EmployeeList from './Components/EmployeeList';
import { empArr } from './Services/data';
import Employees from './Components/Employees';
import Cards from './Components/Cards';

function App() {


  return (
    <div>
      <h1>Employee Table </h1>
      <Employee data={empArr}/>
      <EmployeeList data={empArr}/>
      <Cards/>
      
     
    </div>
  );
}

export default App;
