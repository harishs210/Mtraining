export const empArr=[
    {
      id: 123,
      name : "James",
      dept : "IT",
      grade :"c4",
      sal : 21331231
      
    },
    {
      id: 121,
      name : "Lina",
      dept : "IT",
      grade : "c2",
      sal : 20031231
      
    },
    {
      id: 321,
      name : "Ruby",
      dept : "IT",
      grade : "c3",
      sal : 20331231
    }
  ];

  export const deptArr=[
    {
      id: 100,
      deptName: "IT",
      location : "Chicago"
    },
    {
      id: 200,
      deptName: "Finance",
      location : "Neyyork"
    },
    {
      id: 300,
      deptName: "HRA",
      location : "Colorado"
    }
  ];
  
  