import React from 'react'
import { empArr } from '../Services/data'
function Employees({empSrc}) {
  return (
<tr><td>{empSrc.name}</td><td>{empSrc.dept}</td><td>{empSrc.grade}</td><td>{empSrc.sal}</td></tr>
  )
}

export default Employees