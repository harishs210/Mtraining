import React from 'react'

function EmployeeList(props) {
    const srcdata= props.data;
  return (
    <div>
        <h1>Employee List by name</h1>
        {srcdata.map(emp => emp.name)}

    </div>
  )
}

export default EmployeeList