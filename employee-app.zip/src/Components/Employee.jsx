import React from 'react'
import './Employee.css'
import Employees from './Employees';

function Employee(props) {
    const emps = props.data;
    // const emps = empArr;
  return (
   
    <div className="employeeDiv">
            <table>
                <tr><th>Name</th><th>Dept</th><th>Grade</th><th>Sal</th></tr>
                
                {emps.map(emp => <Employees empSrc={emp} />)}
                
             </table>

    </div>
  )
}

export default Employee