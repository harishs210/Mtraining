import React from 'react'
import cardArr from '../Services/cards'
import './Cards.css'
function Cards() {
  return (

    <div>
      <div className="grid-container">
        {cardArr.map(card =>

          <div className="grid-item">
            <img src={card.cardImg} alt="image" width="300" height="200" />
            <div>
              <h2>{card.cardName}</h2>
              <p>
                {card.cardDesc}
              </p>
            </div>
          </div>

        )}
      </div>
    </div>


  )
}

export default Cards