import React from 'react'

function CoachHome() {
  return (
    <div>CoachHome</div>
  )
}

export default CoachHome