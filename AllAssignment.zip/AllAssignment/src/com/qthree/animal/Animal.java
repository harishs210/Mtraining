package com.qthree.animal;

public abstract class Animal {
	abstract protected void eat();
	abstract protected void sleep();
	

}
