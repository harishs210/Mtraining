package com.qfour.candidate;

public class AgeException extends Exception{

	public AgeException(String message) {
		super(message);
	}

}
