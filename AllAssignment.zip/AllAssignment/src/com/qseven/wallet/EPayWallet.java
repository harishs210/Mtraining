package com.qseven.wallet;

public class EPayWallet {
	
	public static void processPaymentyUser(User user, boolean billAmount) {
		
	}

}
