export const taskList = (state) => state.task.taskList;
export const getTaskLoading = (state) => state.task.getTaskLoading;
export const addTaskLoading = (state) => state.task.addTaskLoading;
export const deleteTaskLoading = (state) => state.task.deleteTaskLoading;
export const updateTaskLoading = (state) => state.task.updateTaskLoading;