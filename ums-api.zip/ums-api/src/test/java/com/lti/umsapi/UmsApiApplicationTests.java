package com.lti.umsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
