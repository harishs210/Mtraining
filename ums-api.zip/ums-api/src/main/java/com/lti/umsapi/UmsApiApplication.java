package com.lti.umsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UmsApiApplication.class, args);
	}

}
