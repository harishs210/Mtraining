import React from 'react'

function CoachHome() {
  return (
    <div>
      coach home
    </div>
  )
}

export default CoachHome
