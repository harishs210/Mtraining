package com.lti.Loandock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanDockApplicationTests {

	@Test
	void contextLoads() {
	}

}
